import { loadUsers, addUser, getUsers } from './data.js'
import {form, inputUser, inputPass,confirmPass, inputEmail, toggleMode, title, submitBtn, message,roles} from './elements.js'
await loadUsers();

let mode = 'Login'


function updateFormUI(e) {

  if (mode === 'Login') {
    title.textContent = 'Login';
    submitBtn.textContent = 'Enter';
    toggleMode.textContent = 'Create one';
    roles.innerHTML = ``;
  } else {
    title.textContent = 'Register user';
    submitBtn.textContent = 'Create account';
    toggleMode.textContent = 'Already have an account';
    roles.innerHTML = `<label class="titles" for="inputConfirmPassword">Confirm Password</label>
                    <input type="password" id="inputPassword" placeholder="Password">`
  }
}

// Register/Login
toggleMode.addEventListener('click', (e) => {
  e.preventDefault()
  mode = mode === 'Login' ? 'Register' : 'Login';
  updateFormUI()
  clearMessage()
})

// Login user
form.addEventListener('submit', (e) => {
  e.preventDefault();

  const userName = inputUser.value.trim();
  const password = inputPass.value.trim();
  const email = inputEmail.value;

  if (!userName || !email || !password) {
    showMessage('Completa todos los campos');
    return;
  }

  if (mode === 'Login') {
    loginUser(userName, email, password);
  } else {
    registerUser(userName, email, password);
  }
});

function loginUser(userName, email, password) {
  const users = getUsers();
  const userFound = users.find(u => u.name === userName && u.email === email && u.password === password)

  if (!userFound) {
    showMessage('User not found')
    return;
  }

  localStorage.setItem('loggedUser', JSON.stringify(userFound))
  window.location.href = './HTML/profile.html'

}

function registerUser(userName, email, password) {
  const users = getUsers()
  const exist = users.find(u => u.name === userName);

  if (exist) {
    showMessage('There is already a user with the same name');
    return;
  }

  const newUser = {
    id: Date.now(),
    name: userName,
    password,
    email
  }

  mode = 'Login'
  addUser(newUser);
  updateFormUI();
  clearMessage()

}

function showMessage(text, type = 'error') {
  message.textContent = text;
  message.className = `form-message ${type}`;
}

function clearMessage() {
  message.textContent = '';
  message.className = 'form-message';
}