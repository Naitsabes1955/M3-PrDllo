const API = 'http://localhost:3000';
const admin = JSON.parse(localStorage.getItem('session'));
if (!admin || admin.role !== 'admin') location.href = '../index.html';


fetch(`${API}/orders`).then(r => r.json()).then(o => {
total.innerText = o.length;
pending.innerText = o.filter(x => x.status === 'pending').length;


orders.innerHTML = o.map(i => `
<tr>
<td>#${i.id}</td>
<td><span class="badge ${i.status}">${i.status}</span></td>
<td>$${i.total}</td>
</tr>`).join('');
});