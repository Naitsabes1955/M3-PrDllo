'use strict'

export let users = [];

// Load Users
export async function loadUsers() {
    const savedUser = localStorage.getItem('users');
    if (savedUser) {
        users = JSON.parse(savedUser);
        return users;
    }
    const res = await fetch('./JSON/users.json');
    users = await res.json();
    localStorage.setItem('users', JSON.stringify(users));
    return users;
};

// Get Users
export function getUsers() {
    return users;
};

// Add User
export function addUser(user) {
    users.push(user);
    localStorage.setItem('users', JSON.stringify(users));
};
