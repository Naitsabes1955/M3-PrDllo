const API = 'http://localhost:3000';

// ELEMENTOS
const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');

// LOGIN
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const email = document.getElementById('email').value;
  const password = document.getElementById('password').value;

  const res = await fetch(`${API}/users?email=${email}&password=${password}`);
  const data = await res.json();

  if (!data.length) {
    alert('Credenciales inválidas');
    return;
  }

  localStorage.setItem('session', JSON.stringify(data[0]));

  if (data[0].role === 'admin') {
    window.location.href = 'admin/dashboard.html';
  } else {
    window.location.href = 'index.html';
  }
});

// REGISTER
registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const name = document.getElementById('name').value;
  const email = document.getElementById('regEmail').value;
  const password = document.getElementById('regPassword').value;

  await fetch(`${API}/users`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      name,
      email,
      password,
      role: 'user'
    })
  });

  alert('Usuario registrado correctamente');
  registerForm.reset();
});
