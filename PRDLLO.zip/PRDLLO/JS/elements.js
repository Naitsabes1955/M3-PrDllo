/* Login */
export const form = document.getElementById('loginform');
export const inputUser = document.getElementById('inputUserName');
export const inputPass = document.getElementById('inputPassword');
export const confirmPass = document.getElementById('inputConfirmPassword');
export const inputEmail = document.getElementById('inputEmail');
export const toggleMode = document.getElementById('toggleMode');
export const title = document.getElementById('formTitle');
export const submitBtn = document.getElementById('submitBtn');
export const message = document.getElementById('formMessage');
export const roles = document.getElementById('roles');

/* Home */
export const newEventInput = document.getElementById("new-event-input");
export const newEventDescription = document.getElementById("new-event-description");
export const newEventDate = document.getElementById("new-event-date");
export const newEventPlace = document.getElementById("new-event-place");
export const addEventButton = document.getElementById("add-event-button");
export const eventsList = document.getElementById("events-list");
