
const newEventInput = document.getElementById("new-event-input");
const newEventDescription = document.getElementById("new-event-description");
const newEventDate = document.getElementById("new-event-date");
const newEventPlace = document.getElementById("new-event-place");
const addEventButton = document.getElementById("add-event-button");
const eventsList = document.getElementById("events-list");

const API = 'http://localhost:3000';
const user = JSON.parse(localStorage.getItem('session'));
if (!user || user.role !== 'user') location.href = 'index.html';


/* Principal Status */
let events = [];

const app = {
    events,
    eventsList,
    newEventInput,
    newEventDescription,
    newEventDate,
    newEventPlace,
};

/* Initial Charge */
window.onload = function () {
    const savedEvents = JSON.parse(localStorage.getItem("events")) || [];

    app.events = savedEvents.map(event => {
        return createEvent(
            event.title,
            event.description || "",
            event.date || "",
            event.place || "",
            event.isCompleted
        );
    });

    app.events.forEach(event => {
        addEventToList(event, app.eventsList);
    });
};

/* Local Storage */
function saveEventsToLocalStorage(events) {
    localStorage.setItem("events", JSON.stringify(events));
}

/* Make Event Object */
function createEvent(title, description,date,place, isCompleted = false) {
    return {
        id: Date.now() + Math.random(), // Añadido un pequeño random para evitar IDs duplicados en cargas masivas
        title,
        description,
        date,
        place,
        isCompleted,
    };
}

/* Add to the DOM */
function addEventToList(event, list) {
    const eventElement = createEventElement(event);
    list.appendChild(eventElement);
}

/* Add New Event */
function addEvent(app) {
    const title = app.newEventInput.value.trim();
    const description = app.newEventDescription.value.trim();
    const date = app.newEventDate.value.trim();
    const place = app.newEventPlace.value.trim()
    if (title === "") return;

    const newEvent = createEvent(title, description, date, place);
    app.events.push(newEvent);

    addEventToList(newEvent, app.eventsList);
    saveEventsToLocalStorage(app.events);

    app.newEventInput.value = "";
    app.newEventDescription.value = "";
    app.newEventDate.value = "";
    app.newEventPlace = "";
}

/* Add visual element */
function createEventElement(event) {
    const li = document.createElement("li");
    li.className = "list-group-item";

    const header = document.createElement("div");
    header.className = "d-flex align-items-start justify-content-between";

    const left = document.createElement("div");
    left.className = "d-flex gap-2";

    const checkbox = document.createElement("input");
    checkbox.type = "checkbox";
    checkbox.checked = event.isCompleted;

    const textContainer = document.createElement("div");

    const title = document.createElement("strong");
    title.textContent = event.title;

    const description = document.createElement("small");
    description.textContent = event.description;
    description.className = "d-block pt-2 pb-2 text-muted";

    const date = document.createElement("small");
    date.textContent = event.date;
    date.className = "d-flex gap-2 pb-2 text-muted"
    
    const place = document.createElement("small");
    place.textContent = event.place;
    place.className = "d-flex gap-2 text-muted"

    textContainer.appendChild(title);
    textContainer.appendChild(description);
    textContainer.appendChild(date);
    textContainer.appendChild(place);

    checkbox.addEventListener("change", () => {
        event.isCompleted = checkbox.checked;
        title.classList.toggle("text-decoration-line-through", event.isCompleted);
        saveEventsToLocalStorage(app.events);
    });

    const deleteButton = document.createElement("button");
    deleteButton.className = "btn btn-sm btn-outline-danger";
    deleteButton.innerHTML = '<i class="bi bi-trash"></i>';

    deleteButton.addEventListener("click", () => {
        if (confirm("Are you sure you want to delete this event?")) {
            li.remove();

            const index = app.events.indexOf(event);
            if (index > -1) {
                app.events.splice(index, 1);
                saveEventsToLocalStorage(app.events);
            }
        }
    });

    left.appendChild(checkbox);
    left.appendChild(textContainer);

    header.appendChild(left);
    header.appendChild(deleteButton);

    li.appendChild(header);

    if (event.isCompleted) {
        title.classList.add("text-decoration-line-through");
    }

    return li;
}

// Button Event
addEventButton.addEventListener("click", () => {
    addEvent(app);
});

