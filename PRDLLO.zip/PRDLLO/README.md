This project had functionality with two diferents models of building, one try to save all the changes but it dont have a filter of priority, status etc, but the second one, have it
I had a big error when i was starting the test, I made other type of test, and i couldn't make a good project, because i felt afraid because that error can cost my study in little words.

This projects try to exemplificate a login, a register, a CRUD making a lists of tasks, and putting the task in the screen.
The project was starting with a list of tasks, trying to follow the Agile methodologhyc scrum with seven primary tasks.

1. An Spa (my bad, because i watched another test)
2. Register And Login. (the user can register an account and will can sig in in the app)
3. Guard for Routes.   (the app have a guardian with the routs for can visite a particular file)
4. Make, management events / CRUD (the other test) (
make: Define title, description, date, ubication.
read/visibility: list events avaible and specific details
update: it will can update the information
delete: the user can delete a task or all the tasks with only one button)
5. Simulate API json-server.
6. LocalStorage
7. Max capacity in registers of events.

The project meets with some things, have:
-Login and Register
-CRUD double
-Local Storage
-Modulation In files
-Change Status and Priority (in one CRUD)
-save date, description, title, in local storage.
-The project meets with own tasks in differents accounts in local stoarage. 

The project fail in:
-Api Simulatedd (json-server)
-Guardian
-Pages dedicated to admin
-profile to user (only have a count and put the name in one crud like an account)

The project used css, bootstrap, html, javascript vanilla etc.
Try is the carpet of files that contain a Crud with well structure for add, remove, filter per status and priority and saving information.

new changes =
-Guardian executing.
-unordened files
-fail with admin-dashboard, don't work.

This project meets with a lot of characteristics, it hasn't could with some things but it was a regular work


and this was the planing of the carpetting
_________________
|--CSS
|---|__login.css
|---|__home.css
|
|--DB
|---|__db.json
|
The project meets with some things, have:
-Login and Register
-CRUD double
-Local Storage
-Modulation In files
-Change Status and Priority (in one CRUD)
-save date, description, title, in local storage.
-The project meets with own tasks in differents accounts in local stoarage. 

Moreover The project fail in:
-Api Simulatedd (json-server)
-Guardian
-Pages dedicated to admin
-profile to user (only have a count and put the name in one crud like an account)

The project used css, bootstrap, html, javascript vanilla etc.
Try is the carpet of files that contain a Crud with well structure for add, remove, filter per status and priority and saving information.

new changes =
-Guardian executing.
-unordened files

|--HTML
|---|__home.html
|
|--JS
|---|__api.js
|---|__app.js
|---|__data.js
|---|__elements.js
|---|__login.js
|---|__main.js
|---|__guard.js (fail)
|_______________

consequently thanks for read :/